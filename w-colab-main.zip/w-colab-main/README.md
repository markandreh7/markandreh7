## __Connect With RDP__
[![Typing SVG](https://readme-typing-svg.herokuapp.com?color=16D400&size=25&width=770&lines=Free+RDP+Google+Colab)](https://git.io/typing-svg)
- RDP
[![Open In Colab RDP](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/akuhnet/w-colab/blob/main/xrdp.ipynb)

- VNC
[![Open In Colab VNC](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1MTDFL2Zc1jsyUgrlgCO0rgdnY_49cNxz)

- W7x86
[![Open In Colab w7](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1cv55uZqWURm6OwQ0xj_I3KMR9sWt8ey3)

- W7x64
[![Open In Colab w7](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/11tufwA1vTze0AGHDZiUMOngISX9zA1x4)

- w10x64
[![Open In Colab w10](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1KXatYukTyT0vKW_xgIb6yKm90vo21LMu)


###
###
[![Typing SVG](https://readme-typing-svg.herokuapp.com?color=16D400&size=25&width=770&lines=Free+RDP+Google+Cloud)](https://git.io/typing-svg)

- [Fedora](https://www.akuh.net/2021/09/free-rdp-google-cloud-fedora.html)
- [Centos 7](https://www.akuh.net/2021/09/free-rdp-google-cloud-centos.html)
- [Centos 8](https://www.akuh.net/2021/09/free-rdp-google-cloud-centos.html)
- [Ubuntu](https://www.akuh.net/2021/09/free-rdp-ubuntu-2004.html)
- [Kali Linux](https://www.akuh.net/2021/09/free-rdp-kali-linux.html)


###
![](https://1.bp.blogspot.com/-y9Y3RURi3wg/YUSbxRPX4gI/AAAAAAAAD6w/Mcfb5Mm_64cJ2XffBHUYTRSix8QDOAu4ACLcBGAsYHQ/s0/RDP%2BColab%2B%25281%2529.gif)
Don't close tab colab to keep rdp running 12 hours
###
## __Tutorials__

1. [__Create Unlimited Gmail__](https://www.youtube.com/watch?v=2LI5IYwF9F8)
1. [__Google Colab RDP__](https://www.akuh.net/2021/08/free-rdp-colab.htm)
1. [__Google Colab VNC__](https://www.akuh.net/2021/06/lifetime-google-colaboratory.html)
1. [__Free Rdp Google Cloud__](https://www.akuh.net/2021/05/vps-google-cloud-free-lifetime-update.html)
2. [__Colab SSH with GPU__](https://github.com/akuhnet/Colab-SSH)
3. [__Other free vps__](https://www.akuh.net/search/label/Vps)

###
###

